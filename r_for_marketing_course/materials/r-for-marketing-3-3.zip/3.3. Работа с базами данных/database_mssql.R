# ������ ������
library(rfacebookstat)
# ��������� �����
options(rfacebookstat.accounts_id  = "act_262115113",
        rfacebookstat.access_token = "<ВАШ_ЗНАЧЕНИЕ>")

my_fb_stats <- fbGetMarketingStat(level = "ad",
                                  fields = "account_name,campaign_name,ad_id,impressions,clicks",
                                  breakdowns = "impression_device",
                                  date_start = Sys.Date() - 20,
                                  date_stop = Sys.Date() - 1,
                                  interval = "day")

# ��������� �������
# devtools::install_github("bescoto/RMSSQL")

# ���������� �����
library(RMSSQL)
library(DBI)

ms_con <- dbConnect(MSSQLServer(), 
                    host     = 'localhost', 
                    user     = 'rteacher', 
                    password = '<ВАШ_ЗНАЧЕНИЕ>', 
                    dbname   = "r_course")

# write data
dbWriteTable(ms_con,
             "fb_data",
             my_fb_stats)

# load data from mysql
mysql_table <- dbReadTable(conn = ms_con, name = "fb_data")

# load by sql query
query_table <- dbGetQuery(conn = ms_con,
                          statement = "SELECT impression_device, SUM(CAST(clicks AS INT)) as clicks
                                       FROM fb_data
                                       GROUP BY impression_device")

# search table
dbListTables(ms_con)
dbExistsTable(conn = ms_con, "fb_data")

# drop table
dbRemoveTable(conn = ms_con, "fb_data")

# check
dbListTables(ms_con)

# disconnet
dbDisconnect(ms_con)
